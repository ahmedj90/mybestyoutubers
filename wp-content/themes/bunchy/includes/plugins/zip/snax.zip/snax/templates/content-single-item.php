<?php
/**
 * Single Item Content Part
 *
 * @package snax
 * @subpackage Theme
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}
?>
<div class="snax">
	<?php do_action( 'snax_before_content_single_item' ); ?>

	<?php snax_get_template_part( 'items/media' ); ?>

	<?php snax_render_item_action_links(); ?>

	<?php snax_get_template_part( 'items/nav' ); ?>

	<?php do_action( 'snax_after_content_single_item' ); ?>
</div>
