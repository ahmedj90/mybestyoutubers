<?php
/**
 * BuddyPress Template Functions
 *
 * @package snax
 * @subpackage BuddyPress
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

add_filter( 'bp_core_admin_get_components',                 'snax_bp_register_custom_components', 10, 2 );
add_filter( 'snax_get_item_author_url',        		        'snax_bp_alter_item_author', 10, 2 );
add_filter( 'snax_user_profile_page',                       'snax_bp_user_profile_page', 10, 2 );

/**
 * Return posts component unique id
 *
 * @return string
 */
function snax_posts_bp_component_id() {
	return 'snax_posts';
}

/**
 * Return items component unique id
 *
 * @return string
 */
function snax_items_bp_component_id() {
	return 'snax_items';
}

/**
 * Return votew component unique id
 *
 * @return string
 */
function snax_votes_bp_component_id() {
	return 'snax_votes';
}

/**
 * Init our custom components states
 *
 * @param bool $force           Skip checking components setup flag.
 */
function snax_bp_activate_components( $force = false ) {
	$snax_bp_components = get_option( 'snax_bp_components' );

	if ( $force || 'loaded' !== $snax_bp_components ) {
		$bp_active_components = bp_get_option( 'bp-active-components', array() );

		$bp_active_components[ snax_posts_bp_component_id() ] = 1;
		$bp_active_components[ snax_items_bp_component_id() ] = 1;
		$bp_active_components[ snax_votes_bp_component_id() ] = 1;

		bp_update_option( 'bp-active-components', $bp_active_components );
		add_option( 'snax_bp_components', 'loaded' );
	}
}

/**
 * Register Snax custom components
 *
 * @param array  $components        Registered components.
 * @param string $type              Component type.
 *
 * @return array
 */
function snax_bp_register_custom_components( $components, $type ) {
	if ( in_array( $type, array( 'all', 'optional' ), true ) ) {

		$posts_id = snax_posts_bp_component_id();
		$items_id = snax_items_bp_component_id();
		$votes_id = snax_votes_bp_component_id();

		// Posts.
		$components[ $posts_id ] = array(
			'title'       => __( 'Snax Posts', 'snax' ),
			'description' => __( 'Manage your posts direclty in your profile.', 'snax' ),
		);

		// Items.
		$components[ $items_id ] = array(
			'title'       => __( 'Snax Submissions', 'snax' ),
			'description' => __( 'Manage your submissions direclty in your profile.', 'snax' ),
		);

		// Votes.
		$components[ $votes_id ] = array(
			'title'       => __( 'Snax Votes', 'snax' ),
			'description' => __( 'Manage your votes direclty in your profile.', 'snax' ),
		);
	}

	return $components;
}

/**
 * Use BP user url as item author page
 *
 * @param string $url           Page url.
 * @param int    $author_id     User id.
 *
 * @return bool|string
 */
function snax_bp_alter_item_author( $url, $author_id ) {
	$url = bp_core_get_userlink( $author_id, false, true );

	return $url;
}

/**
 * Use BP user profile as user profile page
 *
 * @param string $url               Page url.
 * @param int    $user_id           User id.
 *
 * @return string
 */
function snax_bp_user_profile_page( $url, $user_id ) {
	$url = bp_core_get_user_domain( $user_id, false, true );

	return $url;
}

