/* global document */
/* global jQuery */
/* global uploader */
/* global snax */
/* global alert */
/* global confirm */
/* global plupload */
/* global MediumEditor */
/* global snaxDemoItemsConfig */

snax.frontendSubmission = {};

(function ($, ctx) {

    'use strict';

    // Init components.
    $(document).ready(function() {
        ctx.config = $.parseJSON(window.snax_front_submission_config);

        ctx.form.init();
        ctx.tabs.init();
        ctx.uploadImages.init();
        ctx.uploadEmbeds.init();
        ctx.cards.init();
    });

})(jQuery, snax.frontendSubmission);


/*******************
 *
 * Component: Form
 *
 ******************/

(function ($, ctx) {

    'use strict';

    /** CONFIG *******************************************/

    // Register new component.
    ctx.form = {};

    // Component namespace shortcut.
    var c = ctx.form;

    // CSS selectors.
    var selectors = {
        'post':             '.snax-form-frontend',
        'item':             '.snax-object, .snax-card',
        'postTitle':        '#snax-post-title',
        'postTags':         'input#snax-post-tags',
        'postCategory':     'select#snax-post-category',
        'postDescription':  'textarea#snax-post-description',
        'postLegal':        'input#snax-post-legal',
        'postContentTitle': '#snax-post-title-editable',
        'postContentEditor':'textarea.snax-content-editor',
        'insertButton':     '.snax-form-frontend .snax-insert-button',
        'mediaForm':        '.snax-edit-post-row-media'
    };

    var classes = {
        'postWithoutItems': '.snax-form-without-items',
        'validationError':  'snax-validation-error'
    };

    var i18n = {
        'confirm':      'Are you sure?',
        'removeLabel':  'Remove'
    };

    // Allow accessing
    c.selectors = selectors;
    c.classes   = classes;
    c.i18n      = i18n;

    /** INIT *******************************************/

    c.init = function () {
        c.attachEventHandlers();
    };

    /** EVENTS *****************************************/

    c.attachEventHandlers = function() {
        c.validateForm();
        c.focusOnTitle();
        c.categoryRequirement();
        c.applyTagIt();
        c.applyMediumEditor();
        c.resetForm();
    };

    c.resetForm = function () {
        // Empty fields if post has media.
        if (!$(selectors.post).is('.snax-form-frontend-without-media')) {
            c.emptyFields();
        }
    };

    c.categoryRequirement = function() {
        $(selectors.postCategory).on('change', function() {
            var $select = $(this);
            var current = parseInt($select.val(), 10);

            if (-1 !== current) {
                $select.parents('.snax-edit-post-row-categories').removeClass(classes.validationError);
            }
        });
    };

    c.validateForm = function() {
        $(selectors.post).submit(function(e) {
            var $wrapper = $(this);

            // Check if format requires items.
            if ( ! $wrapper.is(classes.postWithoutItems) ) {
                var $items = $wrapper.find(selectors.item);
                var valid;

                valid = $items.length > 0;

                if (!valid) {
                    var errorMessage = 'You need to choose at least one file/embed!';

                    alert(errorMessage);

                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    return false;
                }
            }

            // Check if category selected.
            // @todo - refactor.
            var $categoryWrapper = $('.snax-edit-post-row-categories');

            if ($categoryWrapper.is('.snax-field-required')) {
                // Check if selected.
                var selectedCategory = parseInt($(selectors.postCategory).val(), 10);

                // Not valid.
                if (-1 === selectedCategory) {
                    $categoryWrapper.addClass(classes.validationError);

                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    return false;
                }
            }

            // Text format.
            // @todo - refactor.
            if ($wrapper.is('.snax-form-frontend-format-text')) {
                var $postTitle = $('#snax-post-title');

                // Focus on title field to get focus out of the editor.
                $postTitle.trigger('focus');

                if ($postTitle.val().length === 0) {
                    $('.snax-edit-post-row-title').addClass('snax-validation-error');

                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    return false;
                }

                // Remove p.
                var postContent = $('#snax-post-description').val();
                postContent = postContent.replace(/<p class="">/g, '<p>');
                postContent = postContent.replace(/<p class="snax-embed-layer">/g, '<p>');
                var newPostContent = removep(postContent);

                $('#snax-post-description').val(newPostContent);
            }
        });
    };

    var removep = function( html ) {
        var blocklist = 'blockquote|ul|ol|li|dl|dt|dd|table|thead|tbody|tfoot|tr|th|td|h[1-6]|fieldset',
            blocklist1 = blocklist + '|div|p',
            blocklist2 = blocklist + '|pre',
            preserve_linebreaks = false,
            preserve_br = false;

        if ( ! html ) {
            return '';
        }

        // Protect pre|script tags
        if ( html.indexOf( '<pre' ) !== -1 || html.indexOf( '<script' ) !== -1 ) {
            preserve_linebreaks = true;
            html = html.replace( /<(pre|script)[^>]*>[\s\S]+?<\/\1>/g, function( a ) {
                a = a.replace( /<br ?\/?>(\r\n|\n)?/g, '<wp-line-break>' );
                a = a.replace( /<\/?p( [^>]*)?>(\r\n|\n)?/g, '<wp-line-break>' );
                return a.replace( /\r?\n/g, '<wp-line-break>' );
            });
        }

        // keep <br> tags inside captions and remove line breaks
        if ( html.indexOf( '[caption' ) !== -1 ) {
            preserve_br = true;
            html = html.replace( /\[caption[\s\S]+?\[\/caption\]/g, function( a ) {
                return a.replace( /<br([^>]*)>/g, '<wp-temp-br$1>' ).replace( /[\r\n\t]+/, '' );
            });
        }

        // Pretty it up for the source editor
        html = html.replace( new RegExp( '\\s*</(' + blocklist1 + ')>\\s*', 'g' ), '</$1>\n' );
        html = html.replace( new RegExp( '\\s*<((?:' + blocklist1 + ')(?: [^>]*)?)>', 'g' ), '\n<$1>' );

        // Mark </p> if it has any attributes.
        html = html.replace( /(<p [^>]+>.*?)<\/p>/g, '$1</p#>' );

        // Separate <div> containing <p>
        html = html.replace( /<div( [^>]*)?>\s*<p>/gi, '<div$1>\n\n' );

        // Remove <p> and <br />
        html = html.replace( /\s*<p>/gi, '' );
        html = html.replace( /\s*<\/p>\s*/gi, '\n\n' );
        html = html.replace( /\n[\s\u00a0]+\n/g, '\n\n' );
        html = html.replace( /\s*<br ?\/?>\s*/gi, '\n' );

        // Fix some block element newline issues
        html = html.replace( /\s*<div/g, '\n<div' );
        html = html.replace( /<\/div>\s*/g, '</div>\n' );
        html = html.replace( /\s*\[caption([^\[]+)\[\/caption\]\s*/gi, '\n\n[caption$1[/caption]\n\n' );
        html = html.replace( /caption\]\n\n+\[caption/g, 'caption]\n\n[caption' );

        html = html.replace( new RegExp('\\s*<((?:' + blocklist2 + ')(?: [^>]*)?)\\s*>', 'g' ), '\n<$1>' );
        html = html.replace( new RegExp('\\s*</(' + blocklist2 + ')>\\s*', 'g' ), '</$1>\n' );
        html = html.replace( /<((li|dt|dd)[^>]*)>/g, ' \t<$1>' );

        if ( html.indexOf( '<option' ) !== -1 ) {
            html = html.replace( /\s*<option/g, '\n<option' );
            html = html.replace( /\s*<\/select>/g, '\n</select>' );
        }

        if ( html.indexOf( '<hr' ) !== -1 ) {
            html = html.replace( /\s*<hr( [^>]*)?>\s*/g, '\n\n<hr$1>\n\n' );
        }

        if ( html.indexOf( '<object' ) !== -1 ) {
            html = html.replace( /<object[\s\S]+?<\/object>/g, function( a ) {
                return a.replace( /[\r\n]+/g, '' );
            });
        }

        // Unmark special paragraph closing tags
        html = html.replace( /<\/p#>/g, '</p>\n' );
        html = html.replace( /\s*(<p [^>]+>[\s\S]*?<\/p>)/g, '\n$1' );

        // Trim whitespace
        html = html.replace( /^\s+/, '' );
        html = html.replace( /[\s\u00a0]+$/, '' );

        // put back the line breaks in pre|script
        if ( preserve_linebreaks ) {
            html = html.replace( /<wp-line-break>/g, '\n' );
        }

        // and the <br> tags in captions
        if ( preserve_br ) {
            html = html.replace( /<wp-temp-br([^>]*)>/g, '<br$1>' );
        }

        return html;
    };

    c.focusOnTitle = function () {

        $(selectors.postTitle).each(function() {
            var $title = $(this);

            if ($title.is(':visible') && $title.val().length === 0 && !$title.is('.snax-focused')) {
                $title.focus();
                $title.addClass('snax-focused');
            }
        });

    };

    c.applyTagIt = function () {

        // Check if jQuery script is loaded.
        if (!$.fn.tagit) {
            return;
        }

        $(selectors.postTags).each(function() {
            var $input = $(this);

            var tagsLimit = parseInt(ctx.config.tags_limit, 10);

            var config = {
                'singleField':      true,
                'allowSpaces':      true,
                'tagLimit':         tagsLimit || 10,
                'placeholderText':  $input.prop('placeholder')
            };

            if (typeof c.tagitConfig === 'function') {
                config = c.tagitConfig(config);
            }

            /*
             Change tagIt condig via child theme modifications.js:
             -----------------------------------------------------

             $.ui.keyCode.COMMA = $.ui.keyCode.ENTER; // To prevent comma as a delimiter.

             // Way to override tagIt config. Here to change placeholder text only.
             snax.frontendSubmission.form.tagitConfig = function (config) {
                 config.placeholderText = 'Separate tags with Enter'

                 return config;
             };
             */

            $input.tagit(config);
        });

        $('ul.tagit').each(function() {
            var $this = $(this);

            $this.find( 'input[type=text]' )
                .on('focus', function() {
                    $this.addClass('tagit-focus');
                })
                .on('blur', function() {
                    $this.removeClass('tagit-focus');
                });
        });
    };

    c.applyMediumEditor = function () {

        // Check if editor script is loaded.
        if (typeof MediumEditor === 'undefined') {
            return;
        }

        var $editableTitle   = $(selectors.postContentTitle);
        var $editableContent = $(selectors.postContentEditor);

        // Apply editor to title field.
        if ($editableTitle.length > 0) {
            var titleOptions = {
                disableReturn: true, // one-line field
                disableDoubleReturn: true,
                disableExtraSpaces: true,
                toolbar: false,
                anchorPreview: false,
                placeholder: {
                    text: $(selectors.postTitle).prop('placeholder'),
                    hideOnClick: true
                }
            };

            var $realTitle = $(selectors.postTitle).hide();
            var titleEditor = new MediumEditor(selectors.postContentTitle, titleOptions);

            titleEditor.subscribe('editableInput', function (event, editable) {
                var $editable = $(editable);
                var enteredText = $editable.text();

                if (enteredText.length === 0) {
                    $editable.empty();
                } else {
                    $('.snax-edit-post-row-title').removeClass('snax-validation-error');
                }

                $realTitle.val(enteredText);
            });
        }

        // Apply editor to content field.
        if ($editableContent.length > 0) {
            var SnaxInsertImage = MediumEditor.Extension.extend({
                name: 'snaxInsertImage',

                init: function () {
                    this.$el = $(this.base.elements[0]);
                    this.$el.addClass('snax-insert-image');
                    this.$button = $(selectors.insertButton);
                    this.$form = $(selectors.mediaForm);

                    this.clean();
                    this.events();
                },
                events: function() {
                    var that = this;

                    that.$el.on('keyup click', $.proxy(this, 'editorFocused'));

                    that.base.subscribe('focus', $.proxy(this, 'editorFocused'));

                    that.base.subscribe('blur', $.proxy(this, 'editorBlured'));

                    this.$button.on('click', '.snax-toggle', function(e) {
                        e.preventDefault();

                        var $this = $(this);

                        if ($this.is('.snax-collapsed')) {
                            $this.removeClass('snax-collapsed').addClass('snax-expanded');
                            that.showForm();
                        } else {
                            $this.removeClass('snax-expanded').addClass('snax-collapsed');
                            that.hideForm();
                        }
                    });

                    $('body').on('snaxContentImageAdded', function (e, $image, mediaId) {
                        that.$p.
                        attr('contentEditable', 'false').
                        empty().
                        addClass('snax-editor-figure').
                        append($image);

                        that.clean();
                        that.moveCaret(that.$p.next());

                        that.updateEditorCache(e);

                        $image.on('click touchstart', function() {
                            var $p = $(this).parents('.snax-editor-figure');
                            $p.addClass('snax-focused');

                            // Remove button.
                            var $a = $p.find('.snax-remove');

                            if ($a.length === 0) {
                                $a = $('<a contenteditable="false" class="snax-remove">'+ i18n.removeLabel +'</a>');
                                $p.append($a);

                                $a.on('click', function(e) {
                                    e.preventDefault();

                                    if (!confirm(i18n.confirm)) {
                                        return;
                                    }

                                    that.removeImage(mediaId);
                                    $p.remove();
                                });
                            }

                            // Source.
                            var $source = $p.find('.snax-source');

                            if ($source.length === 0) {
                                var source = $image.attr('data-snax-source') || '';

                                $source = $('<input placeholder="http://" type="text" contenteditable="false" class="snax-source" value="'+ source +'">');
                                $p.append($source);
                            }
                        });
                    });

                    $('body').on('snaxContentEmbedAdded', function (e, $embed) {
                        var $container = $( '<div contenteditable="false" class="snax-editor-figure"></div>').append($embed);

                        that.$p.replaceWith( $container );
                        that.$p = $container;

                        that.clean();
                        that.moveCaret(that.$p.next());

                        that.updateEditorCache(e);

                        $embed.on('click touchstart', function() {
                            var $p = $(this).parents('.snax-csstodo-embed-container');
                            $p.addClass('snax-focused');

                            // Remove button.
                            var $a = $p.find('.snax-embed-layer-remove');

                            if ($a.length === 0) {
                                $a = $('<a href="" contenteditable="false" class="snax-remove">'+ i18n.removeLabel +'</a>');
                                $embed.append($a);

                                $a.on('click', function(e) {
                                    e.preventDefault();

                                    if (!confirm(i18n.confirm)) {
                                        return;
                                    }

                                    $p.remove();
                                });
                            }
                        });
                    });

                    // Hide shares on focus out.
                    $('body').on('click touchstart', function (e) {
                        var $focused = $(e.target).parents('p.snax-focused');

                        $('p.snax-focused').not($focused).each(function () {
                            var $p = $(this);

                            // Remove action button.
                            $p.find('a.snax-remove').remove();

                            // Remove source input.
                            var $source = $p.find('.snax-source');
                            $p.find('img').attr('data-snax-source', $.trim($source.val()));
                            $source.remove();

                            $p.removeClass( 'snax-focused' );

                            that.updateEditorCache(e);
                        });

                        var clickedEditor = $(e.target).parents('.snax-content-editor').length > 0 || $(e.target).is('.snax-content-editor');
                        var clickedButton = $(e.target).parents('.snax-insert-button').length > 0 || $(e.target).is('.snax-insert-button');

                        if (!clickedEditor && !clickedButton) {
                            that.clean();
                        }
                    });
                },
                updateEditorCache: function(e) {
                    this.base.events.updateInput(this.$el.get(0), e);
                },
                editorBlured: function() {},
                editorFocused: function (e) {
                    if (e.type === 'click') {
                        // Simulate the same behaviour as for keyup event (already handled by Medium Editor script).
                        this.handleKeyup(e);
                    }

                    var $el = $(e.target),
                        selection = window.getSelection(),
                        that = this,
                        range,
                        $current,
                        $p;

                    if (!selection || selection.rangeCount === 0) {
                        $current = $el;
                    } else {
                        range = selection.getRangeAt(0);
                        $current = $(range.commonAncestorContainer);
                    }

                    // When user clicks on  editor's placeholder in FF, $current el is editor itself, not the first paragraph as it should
                    if ($current.hasClass('snax-insert-image')) {
                        $current = $current.find('p:first');
                    }

                    $p = $current.is('p') ? $current : $current.closest('p');

                    this.$p = $p;
                    this.clean();

                    // Show actions only for empty paragraphs.
                    if ($p.length && $p.text().trim() === '') {
                        that.showButton();
                    }
                },
                handleKeyup: function(event) {
                    var node = MediumEditor.selection.getSelectionStart(this.base.options.ownerDocument),
                        tagName;

                    if (!node) {
                        return;
                    }

                    // https://github.com/yabwe/medium-editor/issues/994
                    // Firefox thrown an error when calling `formatBlock` on an empty editable blockContainer that's not a <div>
                    if (MediumEditor.util.isMediumEditorElement(node) && node.children.length === 0 && !MediumEditor.util.isBlockContainer(node)) {
                        this.base.options.ownerDocument.execCommand('formatBlock', false, 'p');
                    }

                    // https://github.com/yabwe/medium-editor/issues/834
                    // https://github.com/yabwe/medium-editor/pull/382
                    // Don't call format block if this is a block element (ie h1, figCaption, etc.)
                    if (MediumEditor.util.isKey(event, MediumEditor.util.keyCode.ENTER) &&
                        !MediumEditor.util.isListItem(node) &&
                        !MediumEditor.util.isBlockContainer(node)) {

                        tagName = node.nodeName.toLowerCase();
                        // For anchor tags, unlink
                        if (tagName === 'a') {
                            this.base.options.ownerDocument.execCommand('unlink', false, null);
                        } else if (!event.shiftKey && !event.ctrlKey) {
                            this.base.options.ownerDocument.execCommand('formatBlock', false, 'p');
                        }
                    }
                },
                clean: function() {
                    this.addEmptyLines();

                    this.hideButton();
                    this.hideForm();

                    // Deactivate paragraphs.
                    this.$el.find('.snax-insert-active').removeClass('snax-insert-active');
                },
                showButton: function() {
                    this.$p.addClass('snax-insert-active');
                    this.$el.find('.snax-fix-firefox').removeClass('snax-fix-firefox');

                    var pPos = this.$p.position();

                    this.$button.removeClass('snax-insert-button-off').addClass('snax-insert-button-on');
                    this.$button.show();

                    this.$button.css({
                        'top':      pPos.top
                    });
                },
                hideButton: function() {
                    this.$button.find('.snax-toggle').addClass('snax-collapsed').removeClass('snax-expanded');
                    this.$button.addClass('snax-insert-button-off').removeClass('snax-insert-button-on');

                    this.$button.hide();
                },
                showForm: function() {
                    this.$button.append( this.$form );

                    var buttonTopOffset = parseInt(this.$button.offset().top, 10);
                    var formHeight = parseInt(this.$form.outerHeight(), 10);
                    var windowHeight = parseInt($(window).outerHeight(), 10);

                    if (buttonTopOffset + formHeight > windowHeight) {
                        this.$button.addClass('snax-insert-button-from-bottom');
                    } else {
                        this.$button.removeClass('snax-insert-button-from-bottom');
                    }

                    this.$form.addClass('snax-on').removeClass('snax-off');
                },
                hideForm: function() {
                    this.$form.addClass('snax-off').removeClass('snax-on');
                },
                removeImage: function(mediaId) {
                    snax.deleteMedia({
                        'mediaId':  mediaId,
                        'authorId': snax.currentUserId
                    });
                },
                addEmptyLines: function() {
                    var that = this;
                    var $mediaElements = this.$el.find('.snax-editor-figure');

                    $mediaElements.each(function () {
                        var $element = $(this);

                        // Is last?
                        if ($element.next().length === 0) {
                            $element.after('<p class="snax-fix-firefox"><br></p>'); // add empty paragraph so we can move the caret to the next line.
                        }

                        // Is first?
                        if ($element.prev().length === 0) {
                            $element.before('<p class="snax-fix-firefox"><br></p>'); // add empty paragraph so we can move the caret to the next line.
                        }

                        // Is after media element?
                        if ($element.prev('.snax-editor-figure').length > 0) {
                            $element.before('<p class="snax-fix-firefox"><br></p>'); // add empty paragraph so we can move the caret to the next line.
                        }

                    });

                    // Move caret to last added empty paragraph.
                    var $emptyP = this.$el.find('.snax-fix-firefox');

                    $emptyP.each(function(index) {
                        var $p = $(this);

                        // Last ?
                        if (index === $emptyP.length - 1) {
                            that.moveCaret($p);
                        } else {
                            $p.removeClass('snax-fix-firefox');
                        }
                    });
                },
                moveCaret: function($el, position) {
                    var range, sel, el, textEl;

                    position = position || 0;
                    range = document.createRange();
                    sel = window.getSelection();
                    el = $el.get(0);

                    if (!el) {
                        return;
                    }

                    if (!el.childNodes.length) {
                        textEl = document.createTextNode(' ');
                        el.appendChild(textEl);
                    }

                    range.setStart(el.childNodes[0], position);
                    range.collapse(true);
                    sel.removeAllRanges();
                    sel.addRange(range);

                    // FF fix.
                    this.$el.removeClass('medium-editor-placeholder');
                }
            });

            // Handle content.
            var options = {
                'toolbar': {
                    'buttons': ['bold', 'anchor', 'h2', 'h3', 'quote']
                },
                anchorPreview: {
                    showOnEmptyLinks: false
                },
                extensions: {
                    'snaxInsertImage': new SnaxInsertImage()
                },
                placeholder: {
                    text: $(selectors.postContentEditor).prop('placeholder')
                }
            };

            new MediumEditor(selectors.postContentEditor, options);
        }
    };

    c.emptyFields = function () {
        // Title.
        $(selectors.postTitle).val('');

        // Description.
        $(selectors.postDescription).val('');

        // Category.
        $(selectors.postCategory).find('option:selected').removeAttr('selected');

        // Tags.
        var $tagsInput = $(selectors.postTags);

        $tagsInput.val('');

        if ($.fn.tagit) {
            $tagsInput.tagit('removeAll');
        }

        // Legal.
        $(selectors.postLegal).removeAttr('checked');
    };

})(jQuery, snax.frontendSubmission);

/*******************
 *
 * Component: Tabs
 *
 ******************/

(function ($, ctx) {

    'use strict';

    /** CONFIG *******************************************/

        // Register new component.
    ctx.tabs = {};

    // Component namespace shortcut.
    var c = ctx.tabs;

    // CSS selectors.
    var selectors = {
        'tabsNav':              '.snax-tabs-nav',
        'tabsNavItem':          '.snax-tabs-nav-item',
        'tabsNavItemCurrent':   '.snax-tabs-nav-item-current',
        'tabContent':           '.snax-tab-content',
        'tabContentCurrent':    '.snax-tab-content-current',
        'focusableFields':      'input,textarea'
    };

    // CSS classes.
    var classes = {
        'tabsNavItemCurrent':   'snax-tabs-nav-item-current',
        'tabContentCurrent':    'snax-tab-content-current'
    };

    // Allow accessing
    c.selectors   = selectors;
    c.classes     = classes;

    /** INIT *******************************************/

    c.init = function () {
        c.attachEventHandlers();
    };

    /** EVENTS *****************************************/

    c.attachEventHandlers = function() {

        /* Switch tab */

        $(selectors.tabsNavItem).on('click', function(e) {
            e.preventDefault();

            var $tab = $(this);

            // Remove current selection.
            $(selectors.tabsNavItemCurrent).removeClass(classes.tabsNavItemCurrent);
            $(selectors.tabContentCurrent).removeClass(classes.tabContentCurrent);

            // Select current nav item.
            $tab.addClass(classes.tabsNavItemCurrent);

            // Select current content (with the same index as selected nav item).
            var navItemIndex = $(selectors.tabsNavItem).index($tab);

            var $tabContent = $(selectors.tabContent).eq(navItemIndex);

            $tabContent.addClass(classes.tabContentCurrent);

            // Focus first field.
            $tabContent.find(selectors.focusableFields).filter(':visible:first').focus();
        });

    };

})(jQuery, snax.frontendSubmission);


/**************************
 *
 * Component: Upload Images
 *
 *************************/

(function ($, ctx) {

    'use strict';

    /** CONFIG *******************************************/

    // Register new component
    ctx.uploadImages = {};

    // Component namespace shortcut
    var c = ctx.uploadImages;

    // CSS selectors
    var selectors = {
        'post':                     '.snax-form-frontend',
        'postTitle':                '#snax-post-title',
        'parentFormat':             '.snax-form-frontend input[name=snax-post-format]',
        'form':                     '.snax-tab-content-image',
        'image':                    '.snax-card, .snax-image',
        'imagesWrapper':            '.snax-cards, .snax-edit-post-row-image',
        'imageDelete':              '.snax-image-action-delete',
        'demoImagesWrapper':        '.snax-demo-format',
        'loadDemoImagesButton':     '.snax-demo-format-image > a, .snax-demo-format-images > a',
        'demoImages':               'img',
        // File processing.
        'fileProcessing':           '.snax-xofy-x',
        'filesAll':                 '.snax-xofy-y',
        'filesUploadProgressBar':   '.snax-progress-bar',
        'fileState':                '.snax-state',
        'filesStates':              '.snax-states',
        'statesWrapper':            '.snax-details',
        'feedbackCloseButton':      '.snax-close-button'
    };

    var classes = {
        'postWithoutMedia':     'snax-form-frontend-without-media',
        'postWithMedia':        'snax-form-frontend-with-media',
        'postWithRemovedMedia': 'snax-form-frontend-with-removed-media',
        'formHidden':           'snax-tab-content-hidden',
        'formVisible':          'snax-tab-content-visible',
        // Files processing.
        'fileState':            'snax-state',
        'fileStateProcessing':  'snax-state-processing',
        'fileStateSuccess':     'snax-state-success',
        'fileStateError':       'snax-state-error',
        'fileProcessed':        'snax-details-expanded'
    };

    var i18n = {
        'confirm':              'Are you sure?',
        'multiDropForbidden':   'You can drop only one file here.'
    };

    c.selectors = selectors;
    c.classes   = classes;
    c.i18n      = i18n;

    var $form,
        parentFormat,
        $filesAll,
        $fileProcessing,
        $filesUploadProgressBar,
        $filesStates,
        fakeUpload,
        uploadStarted,                  // Defines if upload process already started.
        filesAll,                       // Number of all chosen by user files.
        filesAllList,                   // List of all file names choses by user.
        fileProcessing,                 // Index of file currently processing.
        filesUploaded,                  // Number of files already uplaoded.
        filesFailed,                    // Number of files that failed to upload.
        fileStates;                     // States of processed files. Format: [ { name: 1.jpg, state: 1 }, ... ].
                                        // States: 1 (success),  -1 (error), file not in array (not processed yet).

    /** INIT *******************************************/

    c.init = function () {
        $form = $(selectors.form);

        if (!$form.length) {
            return;
        }

        parentFormat = $(selectors.parentFormat).val();

        if (parentFormat.length === 0) {
            snax.log('Snax Front Submission Error: Parent format not defined!');
            return;
        }

        if (typeof uploader === 'undefined') {
            snax.log('Snax Front Submission Error: uploader instance not defined!');
            return;
        }

        if (snax.currentUserId === 0) {
            snax.log('Snax: Login required');
            return;
        }

        fakeUpload = false;

        c.initQueue();
        c.attachEventHandlers();
    };

    /** PLUPLOAD ****************************************/

    /*
     * When user choose files to upload, only the filtered files will be processed.
     * Filtered files are those passed all registered filters. Pluplod default filters, in order of registartion and execution:
     * - mime_types,
     * - max_file_size,
     * - prevent_duplicates
     * Custom filters are fired only if all above filter passed. But we want to have access to skipped files.
     * The only way to get full list of chosen by user files (even those that won't be finally processed)
     * is to override first default filter (the 'mime_types' filter) and store file list for futher use.
     */
    plupload.addFileFilter('mime_types', function(filters, file, cb) {
        filesAll++;
        filesAllList.push(file);

        if (filters.length && !filters.regexp.test(file.name)) {
            this.trigger('Error', {
                code : plupload.FILE_EXTENSION_ERROR,
                message : plupload.translate('File extension error.'),
                file : file
            });
            cb(false);
        } else {
            cb(true);
        }
    });

    /** EVENTS *****************************************/

    c.attachEventHandlers = function() {

        /* Upload file */

        c.handleFileUploadEvents();

        /** Delete ***************/

        $(selectors.post).on('click', selectors.imageDelete, function(e) {
            e.preventDefault();

            if (!confirm(i18n.confirm)) {
                return;
            }

            var $image = $(this).parents(selectors.image);

            c.deleteImage($image);

            $(selectors.post).addClass( classes.postWithRemovedMedia );
        });

        /** Upload demo image *******/

        $(selectors.loadDemoImagesButton).on('click', function(e) {
            e.preventDefault();

            var $wrapper = $(this).parents(selectors.demoImagesWrapper);
            var $images = $wrapper.find(selectors.demoImages);
            var imagesCount = $images.length;

            if (imagesCount === 0) {
                return;
            }

            $images.each(function() {
                var imageId = parseInt($(this).attr('data-snax-media-id'), 10);
                var fakeFile = {
                    'id': imageId
                };

                filesAll++;
                filesAllList.push(fakeFile);
            });

            // Fake uploading process.
            fakeUpload = true;

            c.uploadStart();

            var uploadInterval = imagesCount === 1 ? 1000 : 700;

            var fakeUploadImages = function(index) {
                if (index === filesAll || filesAllList.length === 0) {
                    return;
                }

                var fakeFile = filesAllList[index];

                var fakeFileData = {};

                if (typeof snaxDemoItemsConfig !== 'undefined' && snaxDemoItemsConfig[fakeFile.id]) {
                    fakeFileData = snaxDemoItemsConfig[fakeFile.id];
                }

                c.createImageItem(fakeFile.id, null, fakeFileData);

                c.fileProcessed(fakeFile, 1);

                setTimeout(function() {
                    index++;
                    fakeUploadImages(index);
                }, uploadInterval);
            };

            fakeUploadImages(0);
        });

        /** Close feedback *******/

        $(selectors.feedbackCloseButton).on('click', function(e) {
            e.preventDefault();

            snax.hideFeedback();
        });
    };

    c.handleFileUploadEvents = function() {

        uploader.bind('FilesAdded', function(up) {
            fakeUpload = false;

            // Block multiple files dropping.
            if ( ! up.getOption('multi_selection') && up.files.length > 1) {
                alert(i18n.multiDropForbidden);

                while (up.files.length > 0) {
                    up.removeFile(up.files[0]);
                }

                c.initQueue();
                return;

            }

            c.uploadStart();
        });

        uploader.bind('FileUploaded', function (up, file, response) {
            var uploadedMediaId = parseInt(response.response, 10);

            if (!isNaN(uploadedMediaId)) {
                c.createImageItem(uploadedMediaId, function() {
                    c.imageAdded();
                });
            }

            c.uploadSuccess(file, response.response);
        });

        uploader.bind('Error', function (up, err) {
            if (typeof err.file !== 'undefined') {
                c.fileUploadError(err.file);
            }
        });

        uploader.bind('UploadComplete', function () {
            c.uploadComplete();
        });
    };

    /** API *********************************************/

    c.uploadStart = function() {
        if (uploadStarted) {
            return;
        }

        uploadStarted = true;

        c.initFeedback();
    };

    c.uploadSuccess = function(file, response) {
        // If async-upload returned an error message, we need to catch it here.
        if ( response.match(/media-upload-error|error-div/) ) {
            c.fileUploadError(file);
        } else {
            c.fileProcessed(file, 1);
        }
    };

    c.fileProcessed = function(file, status) {
        fileStates[file.id] = status;

        if (status === -1) {
            filesFailed++;
        }
    };

    c.uploadComplete = function() {};

    // This method is triggered when something goest wrong with file upload e.g.:
    // - file is too large
    // - doesn't match allowed mime types
    // - HTTP error during upload
    c.fileUploadError = function(file) {
        // If any of chosen files is valid and normal upload was not fired, we need to init feedback here.
        c.fileProcessed(file, -1);

        // If some error occured and normal upload won't start, we need to run it manually.
        setTimeout(function() {
            c.uploadStart();
        }, 100);
    };

    c.createImageItem = function(id, callback, data) {
        // Don't create Snax item for content images.
        if ('text' === parentFormat) {
            c.addContentImage(id);
        } else {
            callback = callback || function() {};
            data = data || {};

            data = $.extend({
                'mediaId':      id,
                'authorId':     snax.currentUserId,
                'status':       'publish',
                'parentFormat': parentFormat,
                'legal':        true,
                'title':        '',
                'source':       '',
                'description':  ''
            }, data);

            var item = snax.ImageItem(data);

            item.save(function(res) {
                if (res.status === 'success') {
                    switch(parentFormat) {
                        case 'image':
                            c.addImage(res.args.item_id);
                            break;

                        default:
                            ctx.cards.addCard(res.args.item_id);
                    }
                }

                callback(res);
            });
        }
    };

    c.addImage = function(itemId) {
        var xhr = $.ajax({
            'type': 'GET',
            'url': snax.config.ajax_url,
            'dataType': 'json',
            'data': {
                'action':          'snax_load_image_item_tpl',
                'snax_item_id':    itemId
            }
        });

        xhr.done(function (res) {
            if (res.status === 'success') {
                var $image = $(res.args.html);

                $(selectors.imagesWrapper).append($image);

                $(selectors.form).removeClass(classes.formVisible);
                $(selectors.form).addClass(classes.formHidden);
            }
        });
    };

    c.addContentImage = function(mediaId) {
        var xhr = $.ajax({
            'type': 'GET',
            'url': snax.config.ajax_url,
            'dataType': 'json',
            'data': {
                'action':           'snax_load_content_image_tpl',
                'snax_media_id':    mediaId
            }
        });

        xhr.done(function (res) {
            if (res.status === 'success') {
                var $image = $(res.args.html);

                $('body').trigger('snaxContentImageAdded',[$image, mediaId]);
            }
        });
    };

    c.deleteImage = function($image) {
        var $link       = $image.find(selectors.imageDelete);

        snax.deleteItem($link, function(res) {
            if (res.status === 'success') {
                $image.trigger('snaxImageRemoved',[$image]);

                $image.remove();

                $(selectors.form).addClass(classes.formVisible);
                $(selectors.form).removeClass(classes.formHidden);
            }
        });
    };

    c.initFeedback = function() {
        fileProcessing = 1;
        filesUploaded = 0;

        $fileProcessing         = $(selectors.fileProcessing);
        $filesAll               = $(selectors.filesAll);
        $filesUploadProgressBar = $(selectors.filesUploadProgressBar);
        $filesStates            = $(selectors.filesStates);

        // Numbers (1 of 5).
        $fileProcessing.text(fileProcessing);
        $filesAll.text(filesAll);

        // Progress bar.
        $filesUploadProgressBar.css('width', 0);

        // States.
        var i;
        $filesStates.empty();
        $(selectors.statesWrapper).removeClass(classes.fileProcessed);

        for(i = 0; i < filesAll; i++) {
            $filesStates.append('<li class="'+ classes.fileState +'"></li>');
        }

        snax.displayFeedback('processing-files');
        c.startPolling();
    };

    var timer;

    c.startPolling = function() {
        timer = setInterval(function() {
            c.updateFeedback();
        }, 500);
    };

    c.stopPolling = function() {
        clearInterval(timer);
    };

    c.updateFeedback = function() {
        if (c.uploadFinished()) {
            return;
        }

        var currentFileIndex = fileProcessing - 1;
        var currentFile      = filesAllList[currentFileIndex];
        var currentFileState = typeof fileStates[currentFile.id] !== 'undefined' ? fileStates[currentFile.id] : 0;

        var $fileState = $(selectors.filesStates).find(selectors.fileState).eq(currentFileIndex);

        $fileState.addClass(classes.fileStateProcessing);

        if (currentFileState !== 0) {
            $fileState.
                removeClass(classes.fileStateProcessing).
                addClass(currentFileState === 1 ? classes.fileStateSuccess : classes.fileStateError);

            if (currentFileState === -1) {
                var errorMessage = $('#media-item-' + currentFile.id + '.error').text();

                $fileState.text(errorMessage);
            }

            fileProcessing++;
            filesUploaded++;

            var progress = filesUploaded / filesAll * 100;

            $fileProcessing.text(filesUploaded);
            $filesUploadProgressBar.css('width', progress + '%');
        }
    };

    c.uploadFinished = function() {
        var finished = filesUploaded === filesAll;

        if (finished) {
            c.stopPolling();

            if (filesFailed > 0) {
                $(selectors.statesWrapper).addClass(classes.fileProcessed);
            } else {
                setTimeout(function() {
                    $(selectors.post).
                        removeClass(classes.postWithoutMedia + ' ' + classes.postWithRemovedMedia).
                        addClass(classes.postWithMedia);

                    var $postTitle = $(selectors.post).find(selectors.postTitle);

                    // If title has no "snax-focused" class yet,
                    // we can be sure that the form is loaded for the first time.
                    // So we can perform some initial actions.
                    if (!$postTitle.is('.snax-focused')) {
                        // Focus on title.
                        $postTitle.addClass('snax-focused').focus();

                        // Clear demo data.
                        if (!fakeUpload) {
                            ctx.form.emptyFields();
                        }
                    }

                    snax.hideFeedback();
                }, 750);
            }

            c.initQueue();
        }

        return finished;
    };

    c.imageAdded = function() {
    };

    c.initQueue = function() {
        uploadStarted = false;
        filesAll = 0;
        filesAllList = [];
        fileStates = [];
        filesFailed = 0;
    };

})(jQuery, snax.frontendSubmission);


/**************************
 *
 * Component: Upload Embeds
 *
 *************************/

(function ($, ctx) {

    'use strict';

    /** CONFIG *******************************************/

        // Register new component
    ctx.uploadEmbeds = {};

    // Component namespace shortcut
    var c = ctx.uploadEmbeds;

    // CSS selectors
    var selectors = {
        'post':                 '.snax-form-frontend',
        'postTitle':            '#snax-post-title',
        'parentFormat':         '.snax-form-frontend input[name=snax-post-format]',
        'form':                 '.snax-tab-content-embed',
        'embedUrlsField':       '.snax-embed-url-multi',
        'embedUrlField':        '.snax-embed-url',
        'removeEmbedUrlLink':   '.snax-remove-embed',
        'submitField':          'input[name=snax-add-embed-item]',
        'embed':                '.snax-card, .snax-embed',
        'embedsWrapper':        '.snax-cards',
        'embedDelete':          '.snax-embed-action-delete',
        'loadDemoEmbedButton':  '.snax-demo-format-embed > a',
        // Embeds processing.
        'embedProcessing':      '.snax-xofy-x',
        'embedsAll':            '.snax-xofy-y',
        'embedsProgressBar':    '.snax-progress-bar',
        'embedState':           '.snax-state',
        'embedsStates':         '.snax-states',
        'statesWrapper':        '.snax-details',
        'feedbackCloseButton':  '.snax-close-button'
    };

    // CSS classes
    var classes = {
        'embedUrlField':        'snax-embed-url',
        'removeEmbedUrlLink':   'snax-remove-embed',
        'fieldValidationError': 'snax-error',
        'formHidden':           'snax-tab-content-hidden',
        'formVisible':          'snax-tab-content-visible',
        'postWithoutMedia':     'snax-form-frontend-without-media',
        'postWithMedia':        'snax-form-frontend-with-media',
        'postWithRemovedMedia': 'snax-form-frontend-with-removed-media',
        // Embeds processing.
        'embedState':            'snax-state',
        'embedStateProcessing':  'snax-state-processing',
        'embedStateSuccess':     'snax-state-success',
        'embedStateError':       'snax-state-error',
        'embedProcessed':        'snax-details-expanded'
    };

    // i18n.
    var i18n = {
        'confirm':      'Are you sure?'
    };

    c.selectors = selectors;
    c.classes   = classes;
    c.i18n      = i18n;

    var $form,
        parentFormat,
        $embedsAll,
        $embedProcessing,
        $embedsProgressBar,
        $embedsStates,
        fakeUpload,
        embedsAll,
        embedProcessing,
        embedsUploaded,
        embedsFailed,
        embedErrors,
        embedStates;                    // States of processed files. Format: [ { name: 1.jpg, state: 1 }, ... ].
                                        // States: 1 (success),  -1 (error), file not in array (not processed yet).


    /** INIT *******************************************/

    c.init = function () {
        $form = $(selectors.form);

        if (!$form.length) {
            return;
        }

        parentFormat = $(selectors.parentFormat).val();

        if (parentFormat.length === 0) {
            snax.log('Snax Front Submission Error: Parent format not defined!');
            return;
        }

        if (snax.currentUserId === 0) {
            snax.log('Snax: Login required');
            return;
        }

        fakeUpload = false;

        c.attachEventHandlers();
    };

    /** EVENTS *****************************************/

    c.attachEventHandlers = function() {

        /* New url pasted */

        $(document).on('paste drop', selectors.embedUrlsField, function() {
            // Delay to make sure that we can read from the field.
            setTimeout(function () {
                $(selectors.submitField).trigger('click');
            }, 200);
        });

        /* New url typed */

        $(selectors.embedUrlsField).on('focusout', function() {
            if($(this).val().length > 0) {
                $(selectors.submitField).trigger('click');
            }
        });

        /* Submit url */

        $(selectors.submitField).on('click', function(e) {
            e.preventDefault();

            // Collect embed codes.
            var $urls = $form.find(selectors.embedUrlsField);

            var urls = [];
            urls.push($.trim($urls.val()));

            // Clear field.
            $urls.val('');

            // Validate if at least entered.
            if (urls.length === 0) {
                $(selectors.embedUrlsField).addClass(classes.fieldValidationError);
                return;
            } else {
                $(selectors.embedUrlsField).removeClass(classes.fieldValidationError);
            }

            fakeUpload = false;

            c.initFeedback(1);

            urls.reverse();

            c.addEmbedUrls(urls);
        });

        /** Delete ***************/

        $(selectors.embedsWrapper).on('click', selectors.embedDelete, function(e) {
            e.preventDefault();

            if (!confirm(i18n.confirm)) {
                return;
            }

            var $embed = $(this).parents(selectors.embed);

            c.deleteEmbed($embed);
        });

        /** Upload demo embed *******/

        $(selectors.loadDemoEmbedButton).on('click', function(e) {
            e.preventDefault();

            var urls = [
                $(this).attr('href')
            ];

            fakeUpload = true;

            // Fake uploading process.
            c.initFeedback(1);

            c.addEmbedUrls(urls);
        });

        /** Close feedback *******/

        $(selectors.feedbackCloseButton).on('click', function(e) {
            e.preventDefault();

            snax.hideFeedback();
        });
    };

    /** API *********************************************/

    c.addEmbedUrls = function(urls) {
        if (urls.length === 0) {
            c.uploadFinished();
            return;
        }

        var url = urls.pop();

        if ('text' === parentFormat) {
            c.addContentEmbed(url);

            c.embedProcessed(1);

            // Process next url.
            c.addEmbedUrls(urls);
        } else {
            var item = snax.EmbedItem({
                'embedCode':    url,
                'authorId':     snax.currentUserId,
                'status':       'publish',
                'parentFormat': parentFormat,
                'legal':        true
            });

            item.save(function(res) {
                if (res.status === 'success') {
                    switch(parentFormat) {
                        case 'embed':
                            c.addEmbed(res.args.item_id);
                            break;

                        default:
                            ctx.cards.addCard(res.args.item_id);
                    }

                    c.embedProcessed(1);
                } else {
                    c.embedProcessed(-1, res.message);
                }

                // Process next url.
                c.addEmbedUrls(urls);
            });
        }
    };

    c.embedProcessed = function(status, errorMsg) {
        embedStates[embedProcessing - 1] = status;

        if (status === -1) {
            embedsFailed++;
            embedErrors[embedProcessing - 1] = errorMsg;
        }

        // Update feedback.
        embedProcessing++;
        embedsUploaded++;

        c.updateFeedback();
    };

    c.addEmbed = function(itemId) {
        var xhr = $.ajax({
            'type': 'GET',
            'url': snax.config.ajax_url,
            'dataType': 'json',
            'data': {
                'action':          'snax_load_embed_item_tpl',
                'snax_item_id':    itemId
            }
        });

        xhr.done(function (res) {
            if (res.status === 'success') {
                var $embed = $(res.args.html);

                $(selectors.embedsWrapper).append($embed);

                $(selectors.form).removeClass(classes.formVisible);
                $(selectors.form).addClass(classes.formHidden);
            }
        });
    };

    c.addContentEmbed = function(url) {
        var xhr = $.ajax({
            'type': 'POST',
            'url': snax.config.ajax_url,
            'dataType': 'json',
            'data': {
                'action':           'snax_load_content_embed_tpl',
                'snax_embed_code':  url
            }
        });

        xhr.done(function (res) {
            if (res.status === 'success') {
                var $embed = $(res.args.html);

                $('body').trigger('snaxContentEmbedAdded',[$embed]);
            } else {
                alert(res.message);
            }
        });
    };

    c.deleteEmbed = function($embed) {
        var $link       = $embed.find(selectors.embedDelete);

        snax.deleteItem($link, function(res) {
            if (res.status === 'success') {
                $embed.trigger('snaxEmbedRemoved',[$embed]);

                $embed.remove();

                $(selectors.form).addClass(classes.formVisible);
                $(selectors.form).removeClass(classes.formHidden);
            }
        });
    };

    c.initFeedback = function(all) {
        // Init.
        embedProcessing = 1;
        embedsUploaded  = 0;
        embedsAll       = all;
        embedStates     = [];
        embedErrors     = [];
        embedsFailed    = 0;

        $embedProcessing    = $(selectors.embedProcessing);
        $embedsAll          = $(selectors.embedsAll);
        $embedsProgressBar  = $(selectors.embedsProgressBar);
        $embedsStates       = $(selectors.embedsStates);

        $embedProcessing.text(embedProcessing);
        $embedsAll.text(embedsAll);
        $embedsProgressBar.css('width', 0);

        // States.
        var i;
        $embedsStates.empty();

        for(i = 0; i < embedsAll; i++) {
            $embedsStates.append('<li class="'+ classes.embedState +'"></li>');
        }

        snax.displayFeedback('processing-files');
    };

    c.updateFeedback = function() {
        var currentIndex = embedsUploaded - 1;
        var currentState = typeof embedStates[currentIndex] !== 'undefined' ? embedStates[currentIndex] : 0;

        var $embedState = $(selectors.embedsStates).find(selectors.embedState).eq(currentIndex);

        $embedState.addClass(classes.embedStateProcessing);

        if (currentState !== 0) {
            $embedState.
                removeClass(classes.embedStateProcessing).
                addClass(currentState === 1 ? classes.embedStateSuccess : classes.embedStateError);

            if (currentState === -1) {
                var errorMessage = embedErrors[currentIndex];

                $embedState.text(errorMessage);
            }

            var progress = embedsUploaded / embedsAll * 100;

            $embedProcessing.text(embedsUploaded);
            $embedsProgressBar.css('width', progress + '%');
        }
    };

    c.uploadFinished = function() {
        var finished = embedsUploaded === embedsAll;

        if (finished) {
            if (embedsFailed > 0) {
                $(selectors.statesWrapper).addClass(classes.embedProcessed);
            } else {
                setTimeout(function() {
                    $(selectors.post).removeClass(classes.postWithoutMedia).addClass(classes.postWithMedia);

                    var $postTitle = $(selectors.post).find(selectors.postTitle);

                    // If title has no "snax-focused" class yet,
                    // we can be sure that the form is loaded for the first time.
                    // So we can perform some initial actions.
                    if (!$postTitle.is('.snax-focused')) {
                        // Focus on title.
                        $postTitle.addClass('snax-focused').focus();

                        // Clear demo data.
                        if (!fakeUpload) {
                            ctx.form.emptyFields();
                        }
                    }

                    snax.hideFeedback();
                }, 750);
            }
        }

        return finished;
    };

})(jQuery, snax.frontendSubmission);


/********************
 *
 * Component: Cards
 *
 *******************/

(function ($, ctx) {

    'use strict';

    /** CONFIG *******************************************/

    // Register new component
    ctx.cards = {};

    // Component namespace shortcut
    var c = ctx.cards;

    // CSS selectors
    var selectors = {
        'form':             'form.snax-form-frontend',
        'focusableFields':  'input,textarea',
        'card':             '.snax-card',
        'titleField':       'input[name=snax-title]',
        'sourceField':      'input[name=snax-source]',
        'descriptionField': '.snax-card-description > textarea',
        'focusedCard':      '.snax-card-focus',
        'blurredCard':      '.snax-card-blur',
        'cardUp':           '.snax-card-up',
        'cardDown':         '.snax-card-down',
        'cardDelete':       '.snax-card-action-delete',
        'cardPosition':     '.snax-card-position',
        'newEmbeds':        '.snax-new-embeds',
        'addEmbedsField':   'textarea.snax-add-embed-urls',
        'cardsWrapper':     '.snax-cards',
        'publishPostButton':'.snax-button-publish-post',
        'limitReachedNote': '.snax-limit-edit-post-items'
    };


    // CSS classes
    var classes = {
        'focusedCard':      'snax-card-focus',
        'blurredCard':      'snax-card-blur',
        'saving':           'snax-saving',
        'saveFailed':       'snax-save-failed',
        'noteOn':           'snax-note-on',
        'noteOff':          'snax-note-off'
    };

    // i18n.
    var i18n = {
        'confirm':      'Are you sure?'
    };

    c.selectors = selectors;
    c.classes   = classes;
    c.i18n      = i18n;

    var $form,
        cardsLimit,
        cardsCount;

    /** INIT *******************************************/

    c.init = function () {
        $form = $(selectors.form);

        if (!$form.length) {
            return;
        }

        cardsCount = parseInt($form.find(selectors.card).length, 10);
        cardsLimit = parseInt(ctx.config.items_limit, 10);

        c.checkLimits();

        c.attachEventHandlers();
        c.scheduleTasks();
    };

    /** EVENTS *****************************************/

    c.attachEventHandlers = function() {

        /** Focus *********************/

        $(selectors.cardsWrapper).on( 'focus', selectors.focusableFields, function() {
            var $card = $(this).parents(selectors.card);

            // Only if current card is not focused.
            if ( ! $card.is( selectors.focusedCard ) ) {
                // Blur all focused cards.
                $(selectors.focusedCard).toggleClass(classes.blurredCard + ' ' + classes.focusedCard);

                // Focus current.
                $card.toggleClass(classes.blurredCard + ' ' + classes.focusedCard);
            }
        } );

        /** Move up/down **************/

        $(selectors.cardsWrapper).on('click', selectors.cardUp, function(e) {
            e.preventDefault();

            var $card = $(this).parents(selectors.card);

            c.moveCard($card, -1);
        });

        $(selectors.cardsWrapper).on('click', selectors.cardDown, function(e) {
            e.preventDefault();

            var $card = $(this).parents(selectors.card);

            c.moveCard($card, 1);
        });

        /** Delete ***************/

        $(selectors.cardsWrapper).on('click', selectors.cardDelete, function(e) {
            e.preventDefault();

            if (!confirm(i18n.confirm)) {
                return;
            }

            var $card = $(this).parents(selectors.card);

            c.deleteCard($card);
        });

        /** Save posr ************/

        $form.submit(function(e) {
            e.preventDefault();

            var form = this;
            var $button = $(selectors.publishPostButton);

            $button.addClass(classes.saving);

            c.updateCards(function (res) {
                $button.removeClass(classes.saving);

                if (res.status === 'success') {
                    form.submit();
                } else {
                    $button.addClass(classes.saveFailed);
                }
            });
        });

    };

    /** SCHEDULED TASKS ********************************/

    c.scheduleTasks = function() {

        var updateIntervalInSec = parseInt(snax.config.autosave_interval, 10);

        if (updateIntervalInSec <= 0) {
            return;
        }

        setInterval(function () {

            /** Update cards ************/

            c.updateCards();

        }, updateIntervalInSec * 1000);

    };

    /** API *********************************************/

    c.moveCard = function($card, difference) {
        if (difference === 0) {
            return;
        }

        var $cardToSwitchWith = $(); // Empty jQuery object.

        if (difference < 0) {
            while(difference < 0) {
                $cardToSwitchWith = $card.prev(selectors.card);

                // Previous sibling exists so switch.
                if ($cardToSwitchWith.length > 0) {
                    $card.insertBefore($cardToSwitchWith);

                    c.updateCardNumber($card, -1);
                    c.updateCardNumber($cardToSwitchWith, 1);
                }

                difference++;
            }
        }

        if (difference > 0) {
            while(difference > 0) {
                $cardToSwitchWith = $card.next(selectors.card);

                // Next sibling exists so switch.
                if ($cardToSwitchWith.length > 0) {
                    $card.insertAfter($cardToSwitchWith);

                    c.updateCardNumber($card, 1);
                    c.updateCardNumber($cardToSwitchWith, -1);
                }

                difference--;
            }
        }
    };

    c.updateCardNumber = function($card, difference) {
        // Update all cards.
        if (typeof $card === 'undefined') {
            $(selectors.cardPosition).each(function(index) {
                $(this).text(index + 1);
            });

            return;
        }

        // Update single card.
        var $position = $card.find(selectors.cardPosition);
        var newValue = parseInt($position.text(), 10);

        // Using difference param.
        if (typeof difference !== 'undefined') {
            newValue += difference;
            // Using post index.
        } else {
            newValue = $(selectors.card).index($card) + 1;
        }

        $position.text(newValue);
    };

    c.addCard = function(itemId) {
        var xhr = $.ajax({
            'type': 'GET',
            'url': snax.config.ajax_url,
            'dataType': 'json',
            'data': {
                'action':          'snax_load_item_card_tpl',
                'snax_item_id':    itemId
            }
        });

        xhr.done(function (res) {
            if (res.status === 'success') {
                var $card = $(res.args.html);

                $(selectors.cardsWrapper).append($card);

                c.updateCardNumber($card);

                $card.trigger('snaxNewCardAdded',[$card]);

                c.bumpCardsCount(1);
            }
        });
    };

    c.deleteCard = function($card) {
        var $link       = $card.find(selectors.cardDelete);

        snax.deleteItem($link, function(res) {
            if (res.status === 'success') {
                $card.trigger('snaxCardRemoved',[$card]);

                $card.remove();

                c.updateCardNumber();

                c.bumpCardsCount(-1);
            }
        });
    };

    c.updateCards = function (callback) {
        callback = callback || function() {};

        var items = [];

        $(selectors.card).each(function () {
            var $card   = $(this);
            var id      = $card.attr('data-snax-id');
            var $title  = $card.find(selectors.titleField);
            var $source = $card.find(selectors.sourceField);
            var $desc   = $card.find(selectors.descriptionField);

            items.push({
                'id':           id,
                'title':        $.trim($title.val()),
                'source':       $.trim($source.val()),
                'description':  $.trim($desc.val())
            });
        });

        // Nothing to save.
        if (items.length === 0) {
            return callback({ status: 'success' });
        }

        snax.updateItems(items, callback);
    };

    c.bumpCardsCount = function(diff) {
        cardsCount += diff;

        c.checkLimits();
    };

    c.checkLimits = function() {
        if ( cardsLimit !== -1 && cardsCount >= cardsLimit ) {
            $form.find(selectors.limitReachedNote).removeClass('snax-note-off').addClass('snax-note-on');
        } else {
            $form.find(selectors.limitReachedNote).removeClass('snax-note-on').addClass('snax-note-off');
        }
    };

})(jQuery, snax.frontendSubmission);
