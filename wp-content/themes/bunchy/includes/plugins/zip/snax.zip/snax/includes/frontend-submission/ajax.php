<?php
/**
 * Snax Frontend Submission Ajax Functions
 *
 * @package snax
 * @subpackage Ajax
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

/**
 * Return card template (ajax call)
 */
function snax_ajax_load_item_card_tpl() {
	$item_id = filter_input( INPUT_GET, 'snax_item_id', FILTER_SANITIZE_NUMBER_INT );

	if ( ! $item_id ) {
		snax_ajax_response_error( 'Card item id not set!' );
		exit;
	}

	$query = new WP_Query( array(
		'p'                 => $item_id,
		'post_type'         => snax_get_item_post_type(),
		'posts_per_page'    => 1,
	) );

	ob_start();
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) { $query->the_post();
			snax_get_template_part( 'content-card', snax_get_item_format( get_the_ID() ) );
		}

		wp_reset_postdata();
	}

	$tpl = ob_get_clean();

	$response_args = array(
		'html' => $tpl,
	);

	snax_ajax_response_success( 'Card template generated successfully.', $response_args );
	exit;
}

/**
 * Return image item template (ajax call)
 */
function snax_ajax_load_image_item_tpl() {
	$item_id = filter_input( INPUT_GET, 'snax_item_id', FILTER_SANITIZE_NUMBER_INT );

	if ( ! $item_id ) {
		snax_ajax_response_error( 'Image item id not set!' );
		exit;
	}

	$query = new WP_Query( array(
		'p'                 => $item_id,
		'post_type'         => snax_get_item_post_type(),
		'posts_per_page'    => 1,
	) );

	ob_start();
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) { $query->the_post();
			snax_get_template_part( 'content-image' );
		}

		wp_reset_postdata();
	}

	$tpl = ob_get_clean();

	$response_args = array(
		'html' => $tpl,
	);

	snax_ajax_response_success( 'Image template generated successfully.', $response_args );
	exit;
}

/**
 * Return content image template (ajax call)
 */
function snax_ajax_load_content_image_tpl() {
	$media_id = filter_input( INPUT_GET, 'snax_media_id', FILTER_SANITIZE_NUMBER_INT );

	if ( ! $media_id ) {
		snax_ajax_response_error( 'Media id not set!' );
		exit;
	}

	ob_start();
	global $content_width;

	?>
	<?php echo wp_get_attachment_image( $media_id, 'large', false, array( 'contenteditable' => 'false', 'data-snax-id' => $media_id ) ); ?>
	<?php
	$tpl = ob_get_clean();

	$response_args = array(
		'html' => $tpl,
	);

	snax_ajax_response_success( 'Content image template generated successfully.', $response_args );
	exit;
}

/**
 * Return embed item template (ajax call)
 */
function snax_ajax_load_embed_item_tpl() {
	$item_id = filter_input( INPUT_GET, 'snax_item_id', FILTER_SANITIZE_NUMBER_INT );

	if ( ! $item_id ) {
		snax_ajax_response_error( 'Embed item id not set!' );
		exit;
	}

	$query = new WP_Query( array(
		'p'                 => $item_id,
		'post_type'         => snax_get_item_post_type(),
		'posts_per_page'    => 1,
	) );

	ob_start();
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) { $query->the_post();
			snax_get_template_part( 'content-embed' );
		}

		wp_reset_postdata();
	}

	$tpl = ob_get_clean();

	$response_args = array(
		'html' => $tpl,
	);

	snax_ajax_response_success( 'Embed template generated successfully.', $response_args );
	exit;
}

/**
 * Return content embed template (ajax call)
 */
function snax_ajax_load_content_embed_tpl() {
	// Read raw embed code, can be url or iframe.
	$embed_code = filter_input( INPUT_POST, 'snax_embed_code' ); // Use defaulf filter to keep raw code.

	// Sanitize the code, return value must be url to use with [embed] shortcode.
	$embed_meta = snax_get_embed_metadata( $embed_code );

	if ( false === $embed_meta ) {
		snax_ajax_response_error( 'Provided URL or embed code is not allowed!' );
		exit;
	}

	// Fake query, just to allow use of the $wp_embed.
	$query = new WP_Query( array(
		'posts_per_page'    => 1,
	) );

	ob_start();
	?>
	<span class="snax-embed-url"><?php echo esc_url( $embed_meta['url'] ); ?></span>
	<?php
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) { $query->the_post();
			global $wp_embed;

			$shortcode_out = $wp_embed->run_shortcode( '[embed]'. $embed_meta['url'] .'[/embed]' );

			echo filter_var( $shortcode_out );
		}

		wp_reset_postdata();
	}

	$tpl = ob_get_clean();

	$tpl = '<p class="snax-embed-layer">' . $tpl . '</p>';

	$response_args = array(
		'html' => $tpl,
	);

	snax_ajax_response_success( 'Content embed template generated successfully.', $response_args );
	exit;
}
