<?php
/**
 * Snax News Post Row Tags
 *
 * @package snax
 * @subpackage Theme
 */

?>
<div class="snax-edit-post-row-description snax-edit-post-row-content">
	<div class="snax-insert-button snax-insert-button-off">
		<a href="#" class="snax-toggle snax-collapsed"></a>
	</div>
	<textarea id="snax-post-description"
			  class="snax-content-editor"
			  name="snax-post-description"
			  rows="3"
			  cols="40"
			  autocomplete="off"
			  maxlength="<?php echo esc_attr( snax_get_post_content_max_length() ); ?>"
			  placeholder="<?php esc_attr_e( 'Enter some text&hellip;', 'snax' ); ?>"><?php echo esc_textarea( snax_get_field_values( 'description' ) ); ?></textarea>
</div>