/* global document */
/* global jQuery */
/* global snax_admin */

window.snax_admin = {};

(function ($, ns) {

    $(document).ready(function () {

        ns.metaboxes();

    });

})(jQuery, snax_admin);


/*************
 *
 * Metaboxes
 *
 *************/
(function ($, ns) {

    /** CSS *****************/

    var selectors = {
        'toggle': '#snax-metabox-options .snax-forms-toogle',
        'formsWrapper': '#snax-metabox-options-forms'
    };

    var classes = {
        'formsVisible': 'snax-forms-visibility-standard',
        'formsHidden': 'snax-forms-visibility-none'
    };

    /** end of CSS **********/

    ns.metaboxes = function () {

        $(selectors.toggle).on('change', function () {
            $(selectors.formsWrapper).toggleClass(classes.formsVisible + ' ' + classes.formsHidden);
        });

    };

})(jQuery, snax_admin);

/*****************
 *
 * Media Control
 *
 *****************/
(function ($, ns) {

    /** CSS *****************/

    var selectors = {
        'wrapper':      '.snax-media-wrapper',
        'selectButton': '.snax-media-select-button',
        'changeButton': '.snax-media-change-button',
        'removeButton': '.snax-media-remove-button',
        'preview':      '.snax-media-preview',
        'id':           'input.snax-media-id'
    };

    var classes = {
        'visible':      'snax-visible',
        'hidden':       'snax-hidden'
    };

    /** end of CSS **********/

    ns.mediaControl = function () {

        /* Select Image */

        $(selectors.selectButton + ',' + selectors.changeButton).on('click', function (e) {
            e.preventDefault();

            var customFrame;
            var $wrapper        = $(this).parents(selectors.wrapper);
            var $selectButton   = $wrapper.find(selectors.selectButton);
            var $changeButton   = $wrapper.find(selectors.changeButton);
            var $removeButton   = $wrapper.find(selectors.removeButton);
            var $preview        = $wrapper.find(selectors.preview);
            var $id             = $wrapper.find(selectors.id);

            // If the frame already exists, reopen it.
            if (typeof customFrame !== 'undefined') {
                customFrame.close();
            }

            // Create new WP media frame.
            customFrame = wp.media.frames.customHeader = wp.media({
                title: 'Select Image',
                library: {
                    type: 'image'
                },
                button: {
                    text: 'Choose Image'
                },
                multiple: false
            });

            // On image select.
            customFrame.on('select', function() {
                var attachment = customFrame.state().get('selection').first().toJSON();

                $selectButton.removeClass(classes.visible).addClass(classes.hidden);
                $removeButton.removeClass(classes.hidden).addClass(classes.visible);
                $changeButton.removeClass(classes.hidden).addClass(classes.visible);
                $preview.html('<img src="'+ attachment.sizes.thumbnail.url +'">');
                $id.val(attachment.id);
            });

            // Open the frame.
            customFrame.open();
        });

        /* Remove Image */

        $(selectors.removeButton).on('click', function (e) {
            e.preventDefault();

            var $wrapper        = $(this).parents(selectors.wrapper);
            var $selectButton   = $wrapper.find(selectors.selectButton);
            var $changeButton   = $wrapper.find(selectors.changeButton);
            var $removeButton   = $wrapper.find(selectors.removeButton);
            var $preview        = $wrapper.find(selectors.preview);
            var $id             = $wrapper.find(selectors.id);

            $selectButton.removeClass(classes.hidden).addClass(classes.visible);
            $removeButton.removeClass(classes.visible).addClass(classes.hidden);
            $changeButton.removeClass(classes.visible).addClass(classes.hidden);
            $preview.empty();
            $id.val('');
        });
    };

})(jQuery, snax_admin);


