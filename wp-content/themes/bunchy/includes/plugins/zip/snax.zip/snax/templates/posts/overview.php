<?php
/**
 * Snax Post Overview Template Part
 *
 * @package snax
 * @subpackage Theme
 */
